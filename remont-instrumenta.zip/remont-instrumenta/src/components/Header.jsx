


function Header() {
   return (
    <header class="Header">
    <div class="spansDiv">
       <span><a class="a" href="#">О сайте</a></span>
       <span><a class="a" href="#">Главная страница</a></span>
       <span><a class="a" href="#">Список ремонта инструментов</a></span>
    </div>

</header>

   )
}

export default Header