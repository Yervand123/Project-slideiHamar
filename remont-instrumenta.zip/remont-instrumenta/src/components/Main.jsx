

function Main() {
      return (
      <div class='DIVGLOBALIMG'>
        <div class="imgsdiv">
            <a href="#"><img class='IMG' src="img/BoschLogo.jpeg" alt=""/></a>
           <a href="#"><img class='IMG' src="img/DewaltLogo.jpg" alt="" /></a>
           <a href="#"><img  class='IMG'src="img/MakitaLogo.jpg" alt="" /></a> 
        </div>
        </div> 
        
        
      )
}


export default Main