

function Footer() {

 return (

          <div>   
 <footer class="Footer">
 <marquee class="a"  behavior="" direction="left">+37493263716 </marquee>   
 <marquee  class="a" behavior="" direction="right">Г.Веди</marquee>


    <div class="FooterDiv1">
     
    
      
    </div>
      </footer>
      <footer class='Footer2'>
        <div class='icondiv'>
   <a href="https://www.facebook.com/vahagn.petrosian"><i  class='fa fa-facebook-official' id="fa-fa-facebook-official"></i></a> 

    </div>
    <div className="InfoDivFooter">    
      <h1 class='infoh1'>г.Веди</h1>
    <h1 class='infoh1'>тел.+37493090787</h1>
    </div>
    <h3 class='h3about'>this site was created in 2022 by Yervand to repair tools</h3>
      </footer>

      </div>
 )
 }



export default Footer